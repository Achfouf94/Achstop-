import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:intl/intl.dart';
import '../providers/chauffeur_provider.dart';
import '../providers/tournee_provider.dart';
import '../models/chauffeur.dart';
import '../models/colis.dart';

class ManagerDashboardScreen extends StatefulWidget {
  const ManagerDashboardScreen({super.key});
  @override
  State<ManagerDashboardScreen> createState() => _ManagerDashboardScreenState();
}

class _ManagerDashboardScreenState extends State<ManagerDashboardScreen> with SingleTickerProviderStateMixin {
  late TabController _tabs;
  @override
  void initState() { super.initState(); _tabs = TabController(length: 3, vsync: this); }
  @override
  void dispose() { _tabs.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Row(children: [
          Icon(Icons.dashboard_rounded, size: 20),
          SizedBox(width: 8),
          Text('Dashboard Manager'),
        ]),
        bottom: TabBar(
          controller: _tabs,
          indicatorColor: const Color(0xFF01696F),
          labelColor: const Color(0xFF01696F),
          unselectedLabelColor: const Color(0xFF7A7974),
          tabs: const [
            Tab(icon: Icon(Icons.people_alt_outlined, size: 18), text: 'Équipe'),
            Tab(icon: Icon(Icons.analytics_outlined, size: 18), text: 'Perf'),
            Tab(icon: Icon(Icons.map_outlined, size: 18), text: 'Suivi'),
          ],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.person_add_outlined),
            onPressed: () => _ajouterChauffeur(context),
          ),
        ],
      ),
      body: TabBarView(controller: _tabs, children: [
        _EquipeTab(),
        _PerformanceTab(),
        _SuiviTab(),
      ]),
    );
  }

  Future<void> _ajouterChauffeur(BuildContext context) async {
    final nomCtrl = TextEditingController();
    final telCtrl = TextEditingController();
    final vehiculeCtrl = TextEditingController();
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.white,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (_) => Padding(
        padding: EdgeInsets.fromLTRB(20, 20, 20, 20 + MediaQuery.of(context).viewInsets.bottom),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Text('Ajouter un chauffeur', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
          const SizedBox(height: 20),
          TextField(controller: nomCtrl, decoration: const InputDecoration(labelText: 'Nom complet *', prefixIcon: Icon(Icons.person_outline)), autofocus: true),
          const SizedBox(height: 12),
          TextField(controller: telCtrl, keyboardType: TextInputType.phone, decoration: const InputDecoration(labelText: 'Téléphone', prefixIcon: Icon(Icons.phone_outlined))),
          const SizedBox(height: 12),
          TextField(controller: vehiculeCtrl, decoration: const InputDecoration(labelText: 'Véhicule', prefixIcon: Icon(Icons.local_shipping_outlined))),
          const SizedBox(height: 20),
          Row(children: [
            Expanded(child: OutlinedButton(onPressed: () => Navigator.pop(context), child: const Text('Annuler'))),
            const SizedBox(width: 12),
            Expanded(flex: 2, child: ElevatedButton.icon(
              onPressed: () {
                if (nomCtrl.text.trim().isEmpty) return;
                context.read<ChauffeurProvider>().ajouterChauffeur(Chauffeur(
                  nom: nomCtrl.text.trim(),
                  telephone: telCtrl.text.trim().isEmpty ? null : telCtrl.text.trim(),
                  vehicule: vehiculeCtrl.text.trim().isEmpty ? null : vehiculeCtrl.text.trim(),
                ));
                Navigator.pop(context);
              },
              icon: const Icon(Icons.add), label: const Text('Ajouter'),
            )),
          ]),
        ]),
      ),
    );
  }
}

class _EquipeTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<ChauffeurProvider>(builder: (ctx, provider, _) {
      final chauffeurs = provider.chauffeurs;
      if (chauffeurs.isEmpty) {
        return Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
          Icon(Icons.people_outline, size: 64, color: Colors.grey.shade300),
          const SizedBox(height: 16),
          const Text('Aucun chauffeur', style: TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
          const Text('Ajoutez des chauffeurs avec le bouton +', style: TextStyle(color: Color(0xFF7A7974))),
        ]));
      }
      return Column(children: [
        // KPIs équipe
        Padding(
          padding: const EdgeInsets.all(16),
          child: Row(children: [
            _MiniKpi('${chauffeurs.where((c) => c.statut == StatutChauffeur.actif).length}', 'En tournée', const Color(0xFF437A22)),
            const SizedBox(width: 8),
            _MiniKpi('${chauffeurs.where((c) => c.statut == StatutChauffeur.pause).length}', 'En pause', const Color(0xFFDA7101)),
            const SizedBox(width: 8),
            _MiniKpi('${chauffeurs.fold<int>(0, (s, c) => s + c.colisLivresAujourdhui)}', 'Livrés / jour', const Color(0xFF01696F)),
          ]),
        ),
        Expanded(child: ListView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: chauffeurs.length,
          itemBuilder: (_, i) => _ChauffeurCard(chauffeur: chauffeurs[i]),
        )),
      ]);
    });
  }
}

class _ChauffeurCard extends StatelessWidget {
  final Chauffeur chauffeur;
  const _ChauffeurCard({required this.chauffeur});

  Color get _statutColor {
    switch (chauffeur.statut) {
      case StatutChauffeur.actif: return const Color(0xFF437A22);
      case StatutChauffeur.pause: return const Color(0xFFDA7101);
      case StatutChauffeur.horsService: return const Color(0xFF7A7974);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Row(children: [
          // Avatar
          Container(
            width: 48, height: 48,
            decoration: BoxDecoration(color: const Color(0xFF01696F).withOpacity(0.12), borderRadius: BorderRadius.circular(12)),
            child: Center(child: Text(chauffeur.initialesAvatar, style: const TextStyle(color: Color(0xFF01696F), fontWeight: FontWeight.w800, fontSize: 16))),
          ),
          const SizedBox(width: 12),
          Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Text(chauffeur.nom, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
              if (chauffeur.role == RoleChauffeur.manager) ...[
                const SizedBox(width: 6),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(color: const Color(0xFF006494).withOpacity(0.1), borderRadius: BorderRadius.circular(4)),
                  child: const Text('Manager', style: TextStyle(fontSize: 9, color: Color(0xFF006494), fontWeight: FontWeight.w700)),
                ),
              ],
            ]),
            if (chauffeur.vehicule != null) Text('🚚 ${chauffeur.vehicule}', style: const TextStyle(fontSize: 11, color: Color(0xFF7A7974))),
            const SizedBox(height: 4),
            Row(children: [
              Container(width: 7, height: 7, decoration: BoxDecoration(color: _statutColor, shape: BoxShape.circle)),
              const SizedBox(width: 5),
              Text(chauffeur.statutLabel, style: TextStyle(fontSize: 11, color: _statutColor, fontWeight: FontWeight.w600)),
            ]),
          ])),
          Column(crossAxisAlignment: CrossAxisAlignment.end, children: [
            Text('${chauffeur.colisLivresAujourdhui}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: Color(0xFF437A22))),
            const Text('livrés', style: TextStyle(fontSize: 9, color: Color(0xFF7A7974))),
            const SizedBox(height: 6),
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_horiz, color: Color(0xFF7A7974), size: 18),
              onSelected: (v) {
                final p = context.read<ChauffeurProvider>();
                if (v == 'actif') p.changerStatut(chauffeur.id, StatutChauffeur.actif);
                if (v == 'pause') p.changerStatut(chauffeur.id, StatutChauffeur.pause);
                if (v == 'hs') p.changerStatut(chauffeur.id, StatutChauffeur.horsService);
                if (v == 'sup') p.supprimerChauffeur(chauffeur.id);
              },
              itemBuilder: (_) => [
                const PopupMenuItem(value: 'actif', child: Text('🟢 Actif')),
                const PopupMenuItem(value: 'pause', child: Text('🟡 Pause')),
                const PopupMenuItem(value: 'hs', child: Text('⚫ Hors service')),
                const PopupMenuDivider(),
                const PopupMenuItem(value: 'sup', child: Text('Supprimer', style: TextStyle(color: Colors.red))),
              ],
            ),
          ]),
        ]),
      ),
    );
  }
}

class _MiniKpi extends StatelessWidget {
  final String value, label; final Color color;
  const _MiniKpi(this.value, this.label, this.color);
  @override
  Widget build(BuildContext context) => Expanded(child: Container(
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(color: color.withOpacity(0.08), borderRadius: BorderRadius.circular(12), border: Border.all(color: color.withOpacity(0.15))),
    child: Column(children: [
      Text(value, style: TextStyle(fontSize: 22, fontWeight: FontWeight.w900, color: color)),
      Text(label, style: const TextStyle(fontSize: 10, color: Color(0xFF7A7974)), textAlign: TextAlign.center),
    ]),
  ));
}

class _PerformanceTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer2<ChauffeurProvider, TourneeProvider>(builder: (ctx, cProv, tProv, _) {
      final chauffeurs = cProv.chauffeurs;
      final statsGlob = tProv.getStatsGlobales();
      return SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(children: [
          // Global
          Card(child: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Performance globale', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 16)),
            const SizedBox(height: 16),
            Row(children: [
              Expanded(child: _KpiBox('${statsGlob['totalTournees'] ?? 0}', 'Tournées', const Color(0xFF01696F))),
              const SizedBox(width: 8),
              Expanded(child: _KpiBox('${statsGlob['totalLivres'] ?? 0}', 'Livrés', const Color(0xFF437A22))),
              const SizedBox(width: 8),
              Expanded(child: _KpiBox('${(statsGlob['tauxLivraison'] as double? ?? 0).toStringAsFixed(0)}%', 'Taux', const Color(0xFF437A22))),
            ]),
          ]))),
          const SizedBox(height: 16),
          // Classement chauffeurs
          const Text('Classement du jour', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 15)),
          const SizedBox(height: 8),
          ...chauffeurs.asMap().entries.map((e) {
            final c = e.value;
            final rank = e.key + 1;
            return Card(
              margin: const EdgeInsets.only(bottom: 8),
              child: ListTile(
                leading: Container(
                  width: 36, height: 36,
                  decoration: BoxDecoration(
                    color: rank == 1 ? const Color(0xFFD19900).withOpacity(0.15) : rank == 2 ? const Color(0xFF7A7974).withOpacity(0.1) : const Color(0xFFDA7101).withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Center(child: Text(rank == 1 ? '🥇' : rank == 2 ? '🥈' : rank == 3 ? '🥉' : '$rank', style: const TextStyle(fontSize: 16))),
                ),
                title: Text(c.nom, style: const TextStyle(fontWeight: FontWeight.w600)),
                subtitle: c.vehicule != null ? Text(c.vehicule!, style: const TextStyle(fontSize: 11)) : null,
                trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                  Text('${c.colisLivresAujourdhui}', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w900, color: Color(0xFF437A22))),
                  const Text(' livrés', style: TextStyle(fontSize: 11, color: Color(0xFF7A7974))),
                ]),
              ),
            );
          }).toList(),
        ]),
      );
    });
  }
}

class _KpiBox extends StatelessWidget {
  final String value, label; final Color color;
  const _KpiBox(this.value, this.label, this.color);
  @override
  Widget build(BuildContext context) => Column(children: [
    Text(value, style: TextStyle(fontSize: 24, fontWeight: FontWeight.w900, color: color)),
    Text(label, style: const TextStyle(fontSize: 10, color: Color(0xFF7A7974))),
  ]);
}

class _SuiviTab extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Consumer<ChauffeurProvider>(builder: (ctx, provider, _) {
      final actifs = provider.chauffeursActifs;
      return Column(children: [
        Padding(padding: const EdgeInsets.all(16), child: Row(children: [
          const Icon(Icons.location_on, color: Color(0xFF01696F), size: 18),
          const SizedBox(width: 6),
          Text('${actifs.length} chauffeurs actifs', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 14)),
          const Spacer(),
          TextButton.icon(
            onPressed: () { for (final c in actifs) { provider.mettreAJourPosition(c.id); } },
            icon: const Icon(Icons.refresh, size: 16),
            label: const Text('Actualiser'),
          ),
        ])),
        Expanded(child: ListView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          itemCount: actifs.length,
          itemBuilder: (_, i) {
            final c = actifs[i];
            final haPos = c.latitude != null && c.longitude != null;
            final dernPos = c.dernierePosition;
            return Card(
              margin: const EdgeInsets.only(bottom: 10),
              child: ListTile(
                leading: Container(
                  width: 44, height: 44,
                  decoration: BoxDecoration(color: const Color(0xFF01696F).withOpacity(0.1), borderRadius: BorderRadius.circular(10)),
                  child: Center(child: Text(c.initialesAvatar, style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF01696F)))),
                ),
                title: Text(c.nom, style: const TextStyle(fontWeight: FontWeight.w600)),
                subtitle: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(c.statutLabel, style: const TextStyle(fontSize: 11)),
                  if (haPos) Text('${c.latitude!.toStringAsFixed(4)}, ${c.longitude!.toStringAsFixed(4)}', style: const TextStyle(fontSize: 10, color: Color(0xFF01696F), fontFamily: 'monospace')),
                  if (dernPos != null) Text('Màj ${DateFormat('HH:mm').format(dernPos)}', style: const TextStyle(fontSize: 10, color: Color(0xFF7A7974))),
                ]),
                trailing: IconButton(
                  icon: const Icon(Icons.my_location_outlined, color: Color(0xFF01696F)),
                  onPressed: () => provider.mettreAJourPosition(c.id),
                ),
              ),
            );
          },
        )),
      ]);
    });
  }
}
