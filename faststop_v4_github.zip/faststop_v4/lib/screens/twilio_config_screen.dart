import 'package:flutter/material.dart';
import '../services/sms_service.dart';

class TwilioConfigScreen extends StatefulWidget {
  const TwilioConfigScreen({super.key});
  @override
  State<TwilioConfigScreen> createState() => _TwilioConfigScreenState();
}

class _TwilioConfigScreenState extends State<TwilioConfigScreen> {
  final _sidCtrl = TextEditingController();
  final _tokenCtrl = TextEditingController();
  final _numCtrl = TextEditingController();
  final _testTelCtrl = TextEditingController();
  bool _obscureToken = true;
  bool _testEnCours = false;
  String? _testResult;

  @override
  void dispose() { _sidCtrl.dispose(); _tokenCtrl.dispose(); _numCtrl.dispose(); _testTelCtrl.dispose(); super.dispose(); }

  Future<void> _tester() async {
    if (_testTelCtrl.text.trim().isEmpty) return;
    setState(() { _testEnCours = true; _testResult = null; });
    SmsService.configure(accountSid: _sidCtrl.text.trim(), authToken: _tokenCtrl.text.trim(), fromNumber: _numCtrl.text.trim());
    final result = await SmsService.envoyerETA(
      telephone: _testTelCtrl.text.trim(),
      destinataire: 'Test FastStop',
      adresse: 'Adresse de test',
      eta: const Duration(minutes: 15),
      chauffeur: 'Chauffeur test',
    );
    setState(() {
      _testEnCours = false;
      _testResult = result.succes ? '✅ SMS envoyé avec succès ! SID: ${result.sid}' : '❌ Erreur: ${result.message}';
    });
  }

  void _sauvegarder() {
    SmsService.configure(accountSid: _sidCtrl.text.trim(), authToken: _tokenCtrl.text.trim(), fromNumber: _numCtrl.text.trim());
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('✅ Configuration Twilio sauvegardée'), backgroundColor: Color(0xFF437A22)));
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Configuration SMS Twilio')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          // Info
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: const Color(0xFF006494).withOpacity(0.08), borderRadius: BorderRadius.circular(12)),
            child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Row(children: [Icon(Icons.info_outline, size: 16, color: Color(0xFF006494)), SizedBox(width: 8), Text('Comment configurer Twilio ?', style: TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF006494)))]),
              SizedBox(height: 8),
              Text('1. Crée un compte sur twilio.com (gratuit)\n2. Va dans Console > Account Info\n3. Copie Account SID et Auth Token\n4. Achète un numéro de téléphone Twilio (+32 / +33)\n5. Colle les infos ci-dessous', style: TextStyle(fontSize: 12, color: Color(0xFF006494))),
            ]),
          ),
          const SizedBox(height: 20),
          const Text('Identifiants Twilio', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
          const SizedBox(height: 12),
          TextField(
            controller: _sidCtrl,
            decoration: const InputDecoration(labelText: 'Account SID', prefixIcon: Icon(Icons.vpn_key_outlined), hintText: 'ACxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx'),
            style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _tokenCtrl,
            obscureText: _obscureToken,
            decoration: InputDecoration(
              labelText: 'Auth Token',
              prefixIcon: const Icon(Icons.lock_outline),
              hintText: 'Ton auth token Twilio',
              suffixIcon: IconButton(icon: Icon(_obscureToken ? Icons.visibility_outlined : Icons.visibility_off_outlined), onPressed: () => setState(() => _obscureToken = !_obscureToken)),
            ),
            style: const TextStyle(fontFamily: 'monospace', fontSize: 12),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _numCtrl,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(labelText: 'Numéro expéditeur Twilio', prefixIcon: Icon(Icons.phone_outlined), hintText: '+32XXXXXXXXX'),
          ),
          const SizedBox(height: 24),
          const Text('Test d\'envoi', style: TextStyle(fontWeight: FontWeight.w700, fontSize: 14)),
          const SizedBox(height: 12),
          TextField(
            controller: _testTelCtrl,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(labelText: 'Ton numéro de test', prefixIcon: Icon(Icons.smartphone_outlined), hintText: '+32XXXXXXXXX'),
          ),
          const SizedBox(height: 12),
          SizedBox(
            width: double.infinity,
            child: OutlinedButton.icon(
              onPressed: _testEnCours ? null : _tester,
              icon: _testEnCours ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.send_outlined, size: 16),
              label: const Text('Envoyer un SMS de test'),
            ),
          ),
          if (_testResult != null) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _testResult!.startsWith('✅') ? const Color(0xFF437A22).withOpacity(0.08) : const Color(0xFFA12C7B).withOpacity(0.08),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(_testResult!, style: TextStyle(fontSize: 12, color: _testResult!.startsWith('✅') ? const Color(0xFF437A22) : const Color(0xFFA12C7B))),
            ),
          ],
          const SizedBox(height: 28),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: _sauvegarder,
              icon: const Icon(Icons.save_outlined),
              label: const Text('Sauvegarder', style: TextStyle(fontWeight: FontWeight.w700)),
              style: ElevatedButton.styleFrom(padding: const EdgeInsets.symmetric(vertical: 16)),
            ),
          ),
        ]),
      ),
    );
  }
}
