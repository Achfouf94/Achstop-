import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/tournee_provider.dart';
import '../providers/chauffeur_provider.dart';
import '../models/colis.dart';
import '../services/sms_service.dart';

class SmsEtaScreen extends StatefulWidget {
  final String tourneeId;
  const SmsEtaScreen({super.key, required this.tourneeId});
  @override
  State<SmsEtaScreen> createState() => _SmsEtaScreenState();
}

class _SmsEtaScreenState extends State<SmsEtaScreen> {
  final Map<String, bool> _envoiEnCours = {};
  final Map<String, bool> _envoye = {};
  final Map<String, String?> _erreur = {};

  Future<void> _envoyerSMS(BuildContext context, Colis c, String? nomChauffeur) async {
    if (c.telephone == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('❌ Pas de téléphone pour ce colis')));
      return;
    }
    setState(() { _envoiEnCours[c.id] = true; _erreur[c.id] = null; });

    final provider = context.read<TourneeProvider>();
    final tournee = provider.tournees.firstWhere((t) => t.id == widget.tourneeId);
    final position = tournee.colis.where((cc) => cc.statut == StatutLivraison.enAttente && cc.ordre < c.ordre).length;
    final eta = SmsService.estimerETAPourColis(position);

    final result = await SmsService.envoyerETA(
      telephone: c.telephone!,
      destinataire: c.destinataire,
      adresse: c.adresse,
      eta: eta,
      chauffeur: nomChauffeur,
    );

    setState(() {
      _envoiEnCours[c.id] = false;
      _envoye[c.id] = result.succes;
      _erreur[c.id] = result.succes ? null : result.message;
    });

    if (!SmsService.isConfigured) {
      // Mode démo : montrer le message qui serait envoyé
      _montrerPreviewSMS(context, c, eta);
    }
  }

  Future<void> _envoyerAbsence(BuildContext context, Colis c) async {
    if (c.telephone == null) return;
    setState(() => _envoiEnCours[c.id] = true);
    final result = await SmsService.envoyerAbsence(telephone: c.telephone!, destinataire: c.destinataire, adresse: c.adresse);
    setState(() { _envoiEnCours[c.id] = false; _envoye[c.id] = result.succes; });
    if (!SmsService.isConfigured) _montrerPreviewSMS(context, c, null, type: 'absence');
  }

  void _montrerPreviewSMS(BuildContext context, Colis c, Duration? eta, {String type = 'eta'}) {
    final etaStr = eta != null ? (eta.inMinutes < 60 ? '${eta.inMinutes} min' : '${eta.inHours}h${(eta.inMinutes % 60).toString().padLeft(2, '0')}') : '—';
    final message = type == 'eta'
        ? '📦 FastStop — Bonjour ${c.destinataire} !\n\nVotre livraison arrive dans environ $etaStr.\n\nAdresse : ${c.adresse}\n\nMerci de vous assurer d\'être disponible.'
        : '🔔 FastStop — Bonjour ${c.destinataire} !\n\nNous avons tenté de livrer votre colis mais vous étiez absent(e).\n\nAdresse : ${c.adresse}\n\nNous vous recontacterons.';

    showDialog(context: context, builder: (_) => AlertDialog(
      title: const Row(children: [Icon(Icons.sms_outlined, color: Color(0xFF01696F)), SizedBox(width: 8), Text('Prévisualisation SMS')]),
      content: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: const Color(0xFF01696F).withOpacity(0.07), borderRadius: BorderRadius.circular(12)),
          child: Text(message, style: const TextStyle(fontSize: 13)),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(color: const Color(0xFFDA7101).withOpacity(0.08), borderRadius: BorderRadius.circular(8)),
          child: const Row(children: [
            Icon(Icons.info_outline, size: 14, color: Color(0xFFDA7101)),
            SizedBox(width: 6),
            Expanded(child: Text('Mode démo — Configure Twilio dans Paramètres pour envoyer de vrais SMS', style: TextStyle(fontSize: 11, color: Color(0xFFDA7101)))),
          ]),
        ),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Fermer'))],
    ));
  }

  Future<void> _envoyerTous(BuildContext context, List<Colis> colisAvecTel, String? nomChauffeur) async {
    int succes = 0, echecs = 0;
    for (final c in colisAvecTel) {
      if (c.statut == StatutLivraison.enAttente) {
        setState(() => _envoiEnCours[c.id] = true);
        final position = colisAvecTel.where((cc) => cc.ordre < c.ordre).length;
        final eta = SmsService.estimerETAPourColis(position);
        final result = await SmsService.envoyerETA(telephone: c.telephone!, destinataire: c.destinataire, adresse: c.adresse, eta: eta, chauffeur: nomChauffeur);
        setState(() { _envoiEnCours[c.id] = false; _envoye[c.id] = result.succes; });
        if (result.succes) succes++; else echecs++;
        await Future.delayed(const Duration(milliseconds: 500));
      }
    }
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('$succes SMS envoyés${echecs > 0 ? ', $echecs échecs' : ''}'), backgroundColor: const Color(0xFF437A22)));
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<TourneeProvider>();
    final moi = context.watch<ChauffeurProvider>().moi;
    final tournee = provider.tournees.firstWhere((t) => t.id == widget.tourneeId);
    final colisAvecTel = tournee.colis.where((c) => c.telephone != null).toList();
    final colisEnAttente = colisAvecTel.where((c) => c.statut == StatutLivraison.enAttente).toList();

    return Scaffold(
      appBar: AppBar(
        title: const Text('SMS aux destinataires'),
        actions: [
          if (colisEnAttente.isNotEmpty)
            TextButton.icon(
              onPressed: () => _envoyerTous(context, colisAvecTel, moi?.nom),
              icon: const Icon(Icons.send_outlined, size: 16, color: Color(0xFF01696F)),
              label: const Text('Envoyer tout', style: TextStyle(color: Color(0xFF01696F), fontWeight: FontWeight.w600)),
            ),
        ],
      ),
      body: Column(children: [
        // Banner Twilio
        Container(
          margin: const EdgeInsets.all(12),
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: SmsService.isConfigured ? const Color(0xFF437A22).withOpacity(0.08) : const Color(0xFFDA7101).withOpacity(0.08),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: SmsService.isConfigured ? const Color(0xFF437A22).withOpacity(0.2) : const Color(0xFFDA7101).withOpacity(0.2)),
          ),
          child: Row(children: [
            Icon(SmsService.isConfigured ? Icons.check_circle_rounded : Icons.info_outline,
                color: SmsService.isConfigured ? const Color(0xFF437A22) : const Color(0xFFDA7101), size: 18),
            const SizedBox(width: 10),
            Expanded(child: Text(
              SmsService.isConfigured ? '✅ Twilio configuré — SMS réels activés' : '⚠️ Twilio non configuré — mode prévisualisation. Configure dans Paramètres.',
              style: TextStyle(fontSize: 12, color: SmsService.isConfigured ? const Color(0xFF437A22) : const Color(0xFFDA7101)),
            )),
          ]),
        ),
        // Compteur
        Padding(padding: const EdgeInsets.symmetric(horizontal: 16), child: Row(children: [
          Text('${colisAvecTel.length} colis avec téléphone', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
          const Spacer(),
          Text('${colisEnAttente.length} en attente', style: const TextStyle(fontSize: 12, color: Color(0xFF7A7974))),
        ])),
        const SizedBox(height: 8),
        // Liste
        Expanded(child: colisAvecTel.isEmpty
          ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [
              Icon(Icons.sms_outlined, size: 48, color: Colors.grey.shade300),
              const SizedBox(height: 12),
              const Text('Aucun colis avec numéro de téléphone', style: TextStyle(color: Color(0xFF7A7974))),
              const Text('Ajoutez des numéros lors de la création des colis.', style: TextStyle(fontSize: 12, color: Color(0xFFBAB9B4))),
            ]))
          : ListView.builder(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            itemCount: colisAvecTel.length,
            itemBuilder: (_, i) {
              final c = colisAvecTel[i];
              final enCours = _envoiEnCours[c.id] ?? false;
              final envoye = _envoye[c.id] ?? false;
              final err = _erreur[c.id];
              return Card(
                margin: const EdgeInsets.only(bottom: 8),
                child: Padding(padding: const EdgeInsets.all(12), child: Row(children: [
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(c.destinataire, style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 13)),
                    Text(c.telephone!, style: const TextStyle(fontSize: 11, color: Color(0xFF01696F))),
                    Text(c.statutLabel, style: const TextStyle(fontSize: 10, color: Color(0xFF7A7974))),
                    if (err != null) Text(err, style: const TextStyle(fontSize: 10, color: Color(0xFFA12C7B))),
                  ])),
                  Column(children: [
                    if (enCours) const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF01696F)))
                    else if (envoye) const Icon(Icons.check_circle_rounded, color: Color(0xFF437A22), size: 22)
                    else ...[
                      IconButton(
                        icon: const Icon(Icons.send_outlined, color: Color(0xFF01696F), size: 20),
                        onPressed: () => _envoyerSMS(context, c, moi?.nom),
                        tooltip: 'ETA',
                      ),
                      if (c.statut == StatutLivraison.absent)
                        IconButton(
                          icon: const Icon(Icons.person_off_outlined, color: Color(0xFFDA7101), size: 18),
                          onPressed: () => _envoyerAbsence(context, c),
                          tooltip: 'SMS Absent',
                        ),
                    ],
                  ]),
                ])),
              );
            },
          )),
      ]),
    );
  }
}
