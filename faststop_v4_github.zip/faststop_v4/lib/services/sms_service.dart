import 'dart:convert';
import 'package:http/http.dart' as http;

/// Service SMS via Twilio — FastStop V4
/// Envoie des notifications ETA aux destinataires par SMS réels
class SmsService {
  static String _accountSid = '';
  static String _authToken = '';
  static String _fromNumber = '';

  static void configure({required String accountSid, required String authToken, required String fromNumber}) {
    _accountSid = accountSid;
    _authToken = authToken;
    _fromNumber = fromNumber;
  }

  static bool get isConfigured => _accountSid.isNotEmpty && _authToken.isNotEmpty && _fromNumber.isNotEmpty;

  /// Envoyer un SMS ETA au destinataire
  static Future<SmsResult> envoyerETA({
    required String telephone,
    required String destinataire,
    required String adresse,
    required Duration eta,
    String? chauffeur,
  }) async {
    if (!isConfigured) return SmsResult(succes: false, message: 'Twilio non configuré');
    if (telephone.isEmpty) return SmsResult(succes: false, message: 'Numéro de téléphone manquant');

    final etaStr = eta.inMinutes < 60
        ? '${eta.inMinutes} min'
        : '${eta.inHours}h${(eta.inMinutes % 60).toString().padLeft(2, '0')}';

    final heurePrevue = DateTime.now().add(eta);
    final heureFmt = '${heurePrevue.hour.toString().padLeft(2, '0')}:${heurePrevue.minute.toString().padLeft(2, '0')}';

    final body = '📦 FastStop — Bonjour $destinataire !\n\nVotre livraison arrive dans environ $etaStr (vers $heureFmt).\n\nAdresse : $adresse\n${chauffeur != null ? 'Chauffeur : $chauffeur\n' : ''}\nMerci de vous assurer d\'être disponible.';

    try {
      final credentials = base64Encode(utf8.encode('$_accountSid:$_authToken'));
      final resp = await http.post(
        Uri.parse('https://api.twilio.com/2010-04-01/Accounts/$_accountSid/Messages.json'),
        headers: {'Authorization': 'Basic $credentials', 'Content-Type': 'application/x-www-form-urlencoded'},
        body: {'From': _fromNumber, 'To': _normaliserTelephone(telephone), 'Body': body},
      ).timeout(const Duration(seconds: 10));

      if (resp.statusCode == 201) {
        final data = jsonDecode(resp.body);
        return SmsResult(succes: true, sid: data['sid']);
      }
      final err = jsonDecode(resp.body);
      return SmsResult(succes: false, message: err['message'] ?? 'Erreur ${resp.statusCode}');
    } catch (e) {
      return SmsResult(succes: false, message: e.toString());
    }
  }

  /// SMS de confirmation de livraison
  static Future<SmsResult> envoyerConfirmation({
    required String telephone,
    required String destinataire,
    required String numeroSuivi,
  }) async {
    if (!isConfigured) return SmsResult(succes: false, message: 'Twilio non configuré');
    if (telephone.isEmpty) return SmsResult(succes: false, message: 'Téléphone manquant');

    final body = '✅ FastStop — Bonjour $destinataire !\n\nVotre colis $numeroSuivi a été livré avec succès.\n\nMerci de votre confiance.';
    return _envoyer(telephone, body);
  }

  /// SMS d\'absence
  static Future<SmsResult> envoyerAbsence({
    required String telephone,
    required String destinataire,
    required String adresse,
  }) async {
    if (!isConfigured) return SmsResult(succes: false, message: 'Twilio non configuré');
    if (telephone.isEmpty) return SmsResult(succes: false, message: 'Téléphone manquant');

    final body = '🔔 FastStop — Bonjour $destinataire !\n\nNous avons tenté de livrer votre colis à :\n$adresse\n\nVous étiez absent(e). Notre équipe vous recontactera pour planifier une nouvelle livraison.';
    return _envoyer(telephone, body);
  }

  static Future<SmsResult> _envoyer(String telephone, String body) async {
    try {
      final credentials = base64Encode(utf8.encode('$_accountSid:$_authToken'));
      final resp = await http.post(
        Uri.parse('https://api.twilio.com/2010-04-01/Accounts/$_accountSid/Messages.json'),
        headers: {'Authorization': 'Basic $credentials', 'Content-Type': 'application/x-www-form-urlencoded'},
        body: {'From': _fromNumber, 'To': _normaliserTelephone(telephone), 'Body': body},
      ).timeout(const Duration(seconds: 10));
      if (resp.statusCode == 201) return SmsResult(succes: true);
      return SmsResult(succes: false, message: 'Erreur ${resp.statusCode}');
    } catch (e) { return SmsResult(succes: false, message: e.toString()); }
  }

  static String _normaliserTelephone(String tel) {
    tel = tel.replaceAll(RegExp(r'[\s\-\.\(\)]'), '');
    if (tel.startsWith('0')) return '+32${tel.substring(1)}'; // Belgique par défaut
    if (!tel.startsWith('+')) return '+32$tel';
    return tel;
  }

  /// Estimation SMS pour un colis selon sa position dans la file
  static Duration estimerETAPourColis(int positionDansFile, {int minutesParArret = 4}) {
    return Duration(minutes: (positionDansFile + 1) * minutesParArret + 3);
  }
}

class SmsResult {
  final bool succes;
  final String? message;
  final String? sid;
  const SmsResult({required this.succes, this.message, this.sid});
}
