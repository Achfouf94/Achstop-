import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:geolocator/geolocator.dart';
import '../models/chauffeur.dart';

class ChauffeurProvider extends ChangeNotifier {
  static const _boxKey = 'chauffeurs_v4';
  late Box _box;
  List<Chauffeur> _chauffeurs = [];
  Chauffeur? _moi; // Le chauffeur connecté (moi)
  bool _loading = true;

  List<Chauffeur> get chauffeurs => _chauffeurs;
  Chauffeur? get moi => _moi;
  bool get loading => _loading;
  bool get isManager => _moi?.role == RoleChauffeur.manager;
  List<Chauffeur> get chauffeursActifs => _chauffeurs.where((c) => c.statut != StatutChauffeur.horsService).toList();

  Future<void> init() async {
    _box = await Hive.openBox(_boxKey);
    _charger();
    _loading = false;
    notifyListeners();
    // Si aucun chauffeur, créer le profil "moi" par défaut
    if (_chauffeurs.isEmpty) {
      final moi = Chauffeur(nom: 'Mon profil', role: RoleChauffeur.chauffeur, statut: StatutChauffeur.actif);
      _chauffeurs.add(moi);
      _moi = moi;
      await _sauvegarder();
      notifyListeners();
    } else {
      _moi = _chauffeurs.first;
    }
  }

  void _charger() {
    final raw = _box.get('chauffeurs');
    if (raw == null) { _chauffeurs = []; return; }
    try {
      final List list = jsonDecode(raw as String);
      _chauffeurs = list.map((j) => Chauffeur.fromJson(j)).toList();
      final moiRaw = _box.get('moi_id');
      if (moiRaw != null) _moi = _chauffeurs.firstWhere((c) => c.id == moiRaw, orElse: () => _chauffeurs.first);
    } catch (_) { _chauffeurs = []; }
  }

  Future<void> _sauvegarder() async {
    await _box.put('chauffeurs', jsonEncode(_chauffeurs.map((c) => c.toJson()).toList()));
    if (_moi != null) await _box.put('moi_id', _moi!.id);
  }

  Future<void> ajouterChauffeur(Chauffeur c) async {
    _chauffeurs.add(c);
    await _sauvegarder();
    notifyListeners();
  }

  Future<void> mettreAJour(Chauffeur c) async {
    final idx = _chauffeurs.indexWhere((ch) => ch.id == c.id);
    if (idx >= 0) _chauffeurs[idx] = c;
    if (_moi?.id == c.id) _moi = c;
    await _sauvegarder();
    notifyListeners();
  }

  Future<void> supprimerChauffeur(String id) async {
    _chauffeurs.removeWhere((c) => c.id == id);
    await _sauvegarder();
    notifyListeners();
  }

  Future<void> changerStatut(String id, StatutChauffeur statut) async {
    final c = _chauffeurs.firstWhere((ch) => ch.id == id);
    c.statut = statut;
    await _sauvegarder();
    notifyListeners();
  }

  Future<void> mettreAJourPosition(String id) async {
    try {
      final pos = await Geolocator.getCurrentPosition(desiredAccuracy: LocationAccuracy.balanced);
      final c = _chauffeurs.firstWhere((ch) => ch.id == id);
      c.latitude = pos.latitude;
      c.longitude = pos.longitude;
      c.dernierePosition = DateTime.now();
      await _sauvegarder();
      notifyListeners();
    } catch (_) {}
  }

  void setMoi(String id) {
    _moi = _chauffeurs.firstWhere((c) => c.id == id);
    _box.put('moi_id', id);
    notifyListeners();
  }

  Future<void> mettreAJourNom(String id, String nom) async {
    final c = _chauffeurs.firstWhere((ch) => ch.id == id);
    c.nom = nom;
    if (_moi?.id == id) _moi = c;
    await _sauvegarder();
    notifyListeners();
  }
}
