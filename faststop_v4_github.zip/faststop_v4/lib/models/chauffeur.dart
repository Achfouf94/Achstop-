import 'package:uuid/uuid.dart';

enum StatutChauffeur { actif, pause, horsService }
enum RoleChauffeur { manager, chauffeur }

class Chauffeur {
  final String id;
  String nom;
  String? telephone;
  String? email;
  String? vehicule;
  StatutChauffeur statut;
  RoleChauffeur role;
  double? latitude;
  double? longitude;
  DateTime? dernierePosition;
  int colisLivresAujourdhui;
  String? avatarUrl;
  String? deviceToken; // Pour notifications push futures

  Chauffeur({
    String? id,
    required this.nom,
    this.telephone,
    this.email,
    this.vehicule,
    this.statut = StatutChauffeur.actif,
    this.role = RoleChauffeur.chauffeur,
    this.latitude,
    this.longitude,
    this.dernierePosition,
    this.colisLivresAujourdhui = 0,
    this.avatarUrl,
    this.deviceToken,
  }) : id = id ?? const Uuid().v4();

  String get statutLabel {
    switch (statut) {
      case StatutChauffeur.actif: return '🟢 En tournée';
      case StatutChauffeur.pause: return '🟡 En pause';
      case StatutChauffeur.horsService: return '⚫ Hors service';
    }
  }

  String get initialesAvatar {
    final parts = nom.split(' ');
    if (parts.length >= 2) return '${parts[0][0]}${parts[1][0]}'.toUpperCase();
    return nom.substring(0, nom.length > 1 ? 2 : 1).toUpperCase();
  }

  Map<String, dynamic> toJson() => {
    'id': id, 'nom': nom, 'telephone': telephone, 'email': email,
    'vehicule': vehicule, 'statut': statut.index, 'role': role.index,
    'latitude': latitude, 'longitude': longitude,
    'dernierePosition': dernierePosition?.toIso8601String(),
    'colisLivresAujourdhui': colisLivresAujourdhui,
  };

  factory Chauffeur.fromJson(Map<String, dynamic> j) => Chauffeur(
    id: j['id'], nom: j['nom'], telephone: j['telephone'], email: j['email'],
    vehicule: j['vehicule'],
    statut: StatutChauffeur.values[j['statut'] ?? 0],
    role: RoleChauffeur.values[j['role'] ?? 1],
    latitude: (j['latitude'] as num?)?.toDouble(),
    longitude: (j['longitude'] as num?)?.toDouble(),
    dernierePosition: j['dernierePosition'] != null ? DateTime.parse(j['dernierePosition']) : null,
    colisLivresAujourdhui: j['colisLivresAujourdhui'] ?? 0,
  );
}
