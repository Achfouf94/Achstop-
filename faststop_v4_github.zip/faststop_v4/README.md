# 🚚 FastStop V4

Application de livraison professionnelle pour iOS — Développée avec Flutter.

## Fonctionnalités

- 📦 Gestion des colis et tournées
- 🗺️ Carte interactive + optimisation TSP
- 📍 Géocodage automatique des adresses
- 📸 Photo + signature de preuve de livraison
- 📱 Scanner QR / code-barres
- 📊 Statistiques et graphiques
- 💬 SMS ETA aux destinataires (Twilio)
- 👥 Multi-chauffeurs & Dashboard Manager
- ☁️ Sync + mode hors-ligne
- 📄 Export rapport PDF

## Build automatique (GitHub Actions)

Chaque push sur `main` déclenche un build iOS automatique.

➡️ Va dans **Actions** → Dernier run → **Artifacts** → Télécharge `FastStop-V4-IPA`

## Installation sur iPhone

1. Télécharge le IPA depuis les Artifacts GitHub Actions
2. Installe [Sideloadly](https://sideloadly.io) sur ton PC/Mac
3. Connecte ton iPhone par USB
4. Glisse le IPA dans Sideloadly → Install

## Configuration requise

- Flutter 3.29+
- Xcode 15+
- Clé API Google Maps
- Compte Twilio (pour les SMS)

## Lancer en local

```bash
flutter pub get
flutter run -d ios
```

---
Fait avec ❤️ pour mon travail de livreur
