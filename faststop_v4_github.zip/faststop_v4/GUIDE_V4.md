# 🚀 FastStop V4 — Guide d'installation complet

## Nouveautés V4

### ✅ SMS réels aux destinataires (Twilio)
- SMS ETA automatique avant chaque livraison
- SMS de confirmation après livraison
- SMS d'absence si le client n'est pas là
- Preview du message en mode démo (sans Twilio)
- Configuration dans Paramètres > SMS Twilio

### ✅ Multi-chauffeurs & Dashboard Manager
- Ajouter / gérer plusieurs chauffeurs
- Classement des performances du jour
- Suivi en temps réel des positions GPS
- Changer le statut (En tournée / Pause / Hors service)
- Vue Manager avec 3 onglets : Équipe / Perf / Suivi

### ✅ Architecture V4 complète
- Service SMS Twilio (sms_service.dart)
- Modèle Chauffeur (chauffeur.dart)
- Provider Chauffeur (chauffeur_provider.dart)
- Écran Manager Dashboard
- Écran SMS & ETA
- Écran Config Twilio
- main.dart avec MultiProvider

---

## Installation

### 1. Prérequis
- Flutter 3.22+ installé
- Xcode 15+ (pour iOS)
- Un compte Google Cloud Platform (pour Google Maps)
- Un compte Twilio (gratuit pour tester)

### 2. Cloner / Copier le projet
```bash
cd ~/faststop_v4
flutter pub get
```

### 3. Google Maps (iOS)
Édite `ios/Runner/AppDelegate.swift` :
```swift
import GoogleMaps

@main
@objc class AppDelegate: FlutterAppDelegate {
  override func application(...) -> Bool {
    GMSServices.provideAPIKey("TA_CLE_GOOGLE_MAPS_ICI")
    return super.application(application, didFinishLaunchingWithOptions: launchOptions)
  }
}
```

Édite `ios/Runner/Info.plist` → Ajouter :
```xml
<key>NSLocationWhenInUseUsageDescription</key>
<string>FastStop utilise ta position pour optimiser ta tournée</string>
<key>NSLocationAlwaysUsageDescription</key>
<string>FastStop utilise ta position en arrière-plan pour le suivi de tournée</string>
<key>NSCameraUsageDescription</key>
<string>FastStop utilise la caméra pour scanner les codes-barres et prendre des photos de preuve</string>
<key>NSPhotoLibraryUsageDescription</key>
<string>FastStop accède à tes photos pour les preuves de livraison</string>
```

### 4. Twilio (SMS)
1. Crée un compte sur https://www.twilio.com (100$ de crédit gratuit)
2. Va dans Console → Account Info
3. Copie Account SID + Auth Token
4. Achète un numéro (environ 1$/mois)
5. Dans FastStop : Paramètres → SMS Twilio → Colle les infos

### 5. Lancer sur iPhone
```bash
flutter run -d ios
# ou pour build release
flutter build ios --release
```

---

## Architecture des fichiers V4

```
faststop_v4/
├── pubspec.yaml
├── GUIDE_V4.md
└── lib/
    ├── main.dart                          ← App + MultiProvider + Thème
    ├── models/
    │   ├── colis.dart                     ← Modèle colis (V3)
    │   ├── tournee.dart                   ← Modèle tournée (V3)
    │   └── chauffeur.dart                 ← 🆕 Modèle chauffeur V4
    ├── providers/
    │   ├── tournee_provider.dart          ← Provider tournée (V3)
    │   └── chauffeur_provider.dart        ← 🆕 Provider chauffeur V4
    ├── services/
    │   ├── geo_service.dart               ← Haversine + TSP + 2-opt (V3)
    │   ├── notification_service.dart      ← Notifications locales (V3)
    │   ├── cloud_sync_service.dart        ← Sync + hors-ligne (V3)
    │   ├── pdf_service.dart               ← Rapport PDF (V3)
    │   └── sms_service.dart               ← 🆕 SMS Twilio V4
    └── screens/
        ├── home_screen.dart               ← Accueil + tournées
        ├── tournee_screen.dart            ← Vue tournée
        ├── detail_colis_screen.dart       ← Fiche colis
        ├── ajout_colis_screen.dart        ← Ajouter un colis
        ├── scan_screen.dart               ← Scanner QR/barcode
        ├── preuve_livraison_screen.dart   ← Photo + signature
        ├── package_finder_screen.dart     ← Chercher dans le véhicule
        ├── import_csv_screen.dart         ← Import CSV/Excel
        ├── carte_screen.dart              ← Carte + optimisation TSP
        ├── geocodage_screen.dart          ← Géocodage des adresses
        ├── stats_screen.dart              ← Statistiques + graphiques
        ├── parametres_screen.dart         ← Paramètres
        ├── manager_dashboard_screen.dart  ← 🆕 Dashboard multi-chauffeurs
        ├── sms_eta_screen.dart            ← 🆕 SMS aux destinataires
        └── twilio_config_screen.dart      ← 🆕 Config Twilio
```

---

## Flux de travail quotidien

1. **Ouvrir FastStop** → Accueil → Créer une nouvelle tournée
2. **Importer les colis** via CSV ou les saisir manuellement
3. **Géocoder les adresses** → Onglet Géocodage
4. **Optimiser la tournée** → Onglet Carte → bouton ✨ Optimiser
5. **Envoyer les SMS ETA** → Onglet SMS → "Envoyer tout"
6. **Lancer la tournée** → Naviguer arrêt par arrêt
7. **Valider chaque livraison** avec photo + signature
8. **Fin de journée** → Rapport PDF automatique

---

## Roadmap V5
- [ ] Widget iOS écran de verrouillage (Live Activity)
- [ ] Apple Watch companion app
- [ ] Intégration API FedEx / Chronopost directe
- [ ] Navigation vocale intégrée
- [ ] App macOS pour gestionnaire de flotte
